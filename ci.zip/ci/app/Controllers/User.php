<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\API\ResponseTrait;
use CodeIgniter\RESTful\ResourceController;
use Exception;
use \Firebase\JWT\JWT;

// headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=utf8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control");


class User extends ResourceController
{
    use ResponseTrait;

    public function createUser()
    {

        $validation_message = $this->validate([

            'name' => 'required',
            'email' => 'required|valid_email|is_unique[tbl_users.email]',
            'phone_no' => 'required|numeric|max_length[10]',
            'password' => 'required|min_length[6]'

        ]);

        if(!$validation_message){

            $errors = $this->validator->getErrors();

            return $this->respondCreated($errors);
        }else{


        $userModel = new UserModel();

        $data = [
            "name" => $this->request->getVar("name"),
            "email" => $this->request->getVar("email"),
            "phone_no" => $this->request->getVar("phone_no"),
            "password" => password_hash($this->request->getVar("password"), PASSWORD_DEFAULT),
        ];

        if ($userModel->insert($data)) {

            $response = [
                'status' => 200,
                "error" => FALSE,
                'messages' => 'User created',
            ];
        } else {

            $response = [
                'status' => 500,
                "error" => TRUE,
                'messages' => 'Failed to create',
            ];
        }

        return $this->respondCreated($response);

    }
    }

    private function getKey()
    {
        return "my_application_secret";
    }



    public function validateUser()
    {

         $validation_message = $this->validate([

         
            'email' => 'required|valid_email',
            'password' => 'required'

        ]);

           if(!$validation_message){

            $errors = $this->validator->getErrors();

            return $this->respondCreated($errors);
        }else{


      
        //$session = session();

        $userModel = new UserModel();

        $userdata = $userModel->where("email", $this->request->getVar("email"))->first();

        if (!empty($userdata)) {

            if (password_verify($this->request->getVar("password"), $userdata['password'])) {

                $key = $this->getKey();

                $iat = time();
                $nbf = $iat + 10;
                $exp = $iat + 36000000000000000000;

                $payload = array(
                    "iss" => "The_claim",
                    "aud" => "The_Aud",
                    "iat" => $iat,
                    "nbf" => $nbf,
                    "exp" => $exp,
                    "data" => $userdata,
                );

                $token = JWT::encode($payload, $key);

                $data = [

                    'login_key' => $token

                ];

                $session_data = [

                    'session_id' => 'swagata'

                ];

                $userModel->update($userdata['id'],$data);
                //print_r($userdata);

               // $id = $session->set('session_id',$token);

                $response = [
                    'status' => 200,
                    'error' => FALSE,
                    'messages' => 'User logged In successfully',
                    'token' => $token,
                    'user' => $userdata
                ];
                return $this->respondCreated($response);
            } else {

                $response = [
                    'status' => 500,
                    'error' => TRUE,
                    'messages' => 'Incorrect details'
                ];
                return $this->respondCreated($response);
            }
        } else {
            $response = [
                'status' => 500,
                'error' => TRUE,
                'messages' => 'User not found'
            ];
            return $this->respondCreated($response);
        }

}

    }


    public function userDetails()
    {
        $key = $this->getKey();
        $authHeader = $this->request->getHeader("Authorization");
        $authHeader = $authHeader->getValue();
        $token = $authHeader;

        try {
            $decoded = JWT::decode($token, $key, array("HS256"));

            if ($decoded) {

                $response = [
                    'status' => 200,
                    'error' => FALSE,
                    'messages' => 'User Deatils',
                    'data' => $decoded
                ];
               return $this->respondCreated($response);
               // return $this->response->setJSON($response);

            }
        } catch (Exception $ex) {
            $response = [
                'status' => 401,
                'error' => TRUE,
                'messages' => 'Access denied'
            ];
            return $this->respondCreated($response);
        }
    }


     public function updates()
    {

$key = $this->getKey();
        $authHeader = $this->request->getHeader("Authorization");
        $authHeader = $authHeader->getValue();
        $token = $authHeader;

        try {
            $decoded = JWT::decode($token, $key, array("HS256"));

            if ($decoded) {


        ///////
        $userModel = new UserModel();

        $data = [
            "name" => $this->request->getVar("name"),
            "email" => $this->request->getVar("email"),
            "phone_no" => $this->request->getVar("phone_no"),
           // "password" => password_hash($this->request->getVar("password"), PASSWORD_DEFAULT),
            
        ];

        $id = $this->request->getVar("id");

        if ($userModel->update($id,$data)) {

            $response = [
                'status' => 200,
                "error" => FALSE,
                'messages' => 'User updated',
            ];
        } else {

            $response = [
                'status' => 500,
                "error" => TRUE,
                'messages' => 'Failed to update',
            ];
        }

        return $this->respondCreated($response);

              /////////
               
            }
        } catch (Exception $ex) {
            $response = [
                'status' => 401,
                'error' => TRUE,
                'messages' => 'Access denied'
            ];
            return $this->respondCreated($response);
        }


    }




     public function updates2()
    {



        ///////
        $userModel = new UserModel();

        $data = [
            "name" => $this->request->getVar("name"),
            "email" => $this->request->getVar("email"),
            "phone_no" => $this->request->getVar("phone_no"),
           // "password" => password_hash($this->request->getVar("password"), PASSWORD_DEFAULT),
            
        ];

        $id = $this->request->getVar("id");

        if ($userModel->update($id,$data)) {

            $response = [
                'status' => 200,
                "error" => FALSE,
                'messages' => 'User updated',
            ];
        } else {

            $response = [
                'status' => 500,
                "error" => TRUE,
                'messages' => 'Failed to update',
            ];
        }

        return $this->respondCreated($response);

              /////////
               
            
        


    }




     public function deletes()
    {

$key = $this->getKey();
        $authHeader = $this->request->getHeader("Authorization");
        $authHeader = $authHeader->getValue();
        $token = $authHeader;

        try {
            $decoded = JWT::decode($token, $key, array("HS256"));

            if ($decoded) {


        ///////
        $userModel = new UserModel();


        $id = $this->request->getVar("id");

        if ($userModel->delete($id)) {

            $response = [
                'status' => 200,
                "error" => FALSE,
                'messages' => 'User deleted',
            ];
        } else {

            $response = [
                'status' => 500,
                "error" => TRUE,
                'messages' => 'Failed to delete',
            ];
        }

        return $this->respondCreated($response);

              /////////
               
            }
        } catch (Exception $ex) {
            $response = [
                'status' => 401,
                'error' => TRUE,
                'messages' => 'Access denied'
            ];
            return $this->respondCreated($response);
        }


    }



    public function userfetch(){

        $id = $this->request->getVar('id');
           $usermodel = new UserModel();
        $user = $usermodel->find($id);

         $response = [
                'user' => $user
            ];

         return $this->respondCreated($response);
    }






    public function addUser(){


        $validation_message = $this->validate([

            'name' => 'required',
            'email' => 'required|valid_email|is_unique[tbl_users.email]',
            'phone_no' => 'required|numeric|max_length[10]',
            'password' => 'required|min_length[6]'

        ]);

        if(!$validation_message){

            $errors = $this->validator->getErrors();

            return $this->respondCreated($errors);
        }else{


     $data = [
          
          'name' => $this->request->getVar('name'),
          'email' => $this->request->getVar('email'),
          'phone_no' => $this->request->getVar('phone_no'),
          'password' => password_hash($this->request->getVar("password"), PASSWORD_DEFAULT),
          'add_by' => $this->request->getVar('token_email'),
          'login_key' => $this->request->getVar('token')


     ];

     $user = new UserModel();

    if ($user->insert($data)) {

            $response = [
                'status' => 200,
                "error" => FALSE,
                'messages' => 'User created',
            ];
        } else {

            $response = [
                'status' => 500,
                "error" => TRUE,
                'messages' => 'Failed to create',
            ];
        }

        return $this->respondCreated($response);

    }

    }




    public function details(){
     //$session = session();

      //$value = $session->get('session_id');
 
       $token = $this->request->getVar('token');
       $token_email = $this->request->getVar('token_email');

       $user = new UserModel();

       $query = $user->where('add_by',$token_email)->findAll();

          $response = [

               'data' => $query
          ];

        return $this->respondCreated($response);


    }



    public function userdelete(){

        $id = $this->request->getVar('id');

        $user = new UserModel();

        $user->where('id',$id)->delete();
    }




}

