<?php

namespace App\Controllers;


class ApiController extends Controller{


	public function userfetch(){

		return "hello";
	}
}


?>